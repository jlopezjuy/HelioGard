# Instrucciones de agente para SolarCare

Implementar SOLO el frontend Angular + Tailwind de la hackatón con datos mock locales. Antes de tocar código, leer íntegramente `prompts/PROMPT_MAESTRO_ANGULAR_FRONTEND_MOCK_V3.md` y `specs/domain.v2.draft.jdl`; luego seguir los enlaces a `docs/FRONTEND_FIRST_SPRINTS_V3.md`, `docs/JDL_FRONTEND_ENTITY_MATRIX_V3.md`, `docs/DESIGN_SYSTEM_QUEBRADA_V3.md` y `skills/solarcare-visual-design/SKILL.md`.

No crear backend ni declarar que el JDL fue importado. No reemplazar archivos existentes sin inspección. Ejecutar build/tests realmente y documentar resultados honestamente.
