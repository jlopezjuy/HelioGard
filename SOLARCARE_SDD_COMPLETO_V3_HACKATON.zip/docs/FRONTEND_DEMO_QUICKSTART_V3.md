# SolarCare — Inicio rápido de la demostración Angular

**Este paquete NO incluye un frontend generado.** Incluye un plan SDD y un prompt portable para que Codex, Claude Code, Gemini CLI u otro agente implementen Angular + Tailwind sin backend.

## Uso más rápido

1. Crear una carpeta de trabajo `solarcare/` y **extraer allí el contenido del ZIP**; debe quedar `solarcare/specs/`, `solarcare/docs/`, `solarcare/prompts/` y `solarcare/README.md`. Si ya existe un repositorio, inspeccionar colisiones antes de copiar.
2. Abrir la raíz del repositorio con el agente de código.
3. Copiar el contenido de `prompts/PROMPT_MAESTRO_ANGULAR_FRONTEND_MOCK_V3.md` como instrucción principal.
4. Permitir acceso local a leer archivos y ejecutar `node/npm/ng`; **no se necesita conectar el VPS ni JHipster** para el demo frontend.
5. Pedir al agente que complete F0–F7, `ng build`, pruebas y capturas antes de entregar.
6. Ejecutar `npm start` o `ng serve` desde `apps/solarcare-web`, cuando el agente realmente haya creado esa app.

## Filosofía del demo

- Datos ficticios, deterministas, con modo DEMO visible.
- Roles y multiempresa simulados, no seguridad real.
- Entidades JDL v2 como contrato; sin generar CRUD automático superficial.
- Repositorios mock intercambiables por HTTP cuando el backend JHipster esté disponible.
- Diseño basado en Estratos de la Quebrada; iconografía profesional y QA visual real.

## Artefactos clave

- `docs/JDL_FRONTEND_ENTITY_MATRIX_V3.md`
- `docs/FRONTEND_FIRST_SPRINTS_V3.md`
- `docs/DESIGN_SYSTEM_QUEBRADA_V3.md`
- `skills/solarcare-visual-design/SKILL.md`
- `frontend-demo/design-tokens.tailwind-v4.css`
- `frontend-demo/demo-fixtures.example.json`

**No ejecutar los contenedores edge/cloud para la demo Angular; son parte de la arquitectura de producción, no requisitos del frontend.**

## Docker opcional para mostrarlo en otro equipo

Cuando Angular haya sido generado, se puede construir una imagen estática local con `infra/Dockerfile.web-demo.example`, `infra/nginx.web-demo.conf` e `infra/compose.web-demo.example.yaml`. Antes de hacerlo, comprobar la ruta `dist/.../browser` resultante del CLI y adaptar el Dockerfile. **No se probó el build Docker porque no existe aún el frontend generado.**
