# Comandos CLI — arranque guiado (no ejecutados)

Requisito: verificar Java >=21 y versión concreta del generador JHipster, Node compatible con Angular, Docker Compose v2, FVM/Flutter y SDK móviles. El frontend demo funciona por sí solo y usa Tailwind; no necesita ejecutar backend.

## Backend JHipster

```bash
npm install -g generator-jhipster@9.4.0
mkdir -p apps/solarcare-api && cd apps/solarcare-api
jhipster --skip-client
# Elegir monolith, PostgreSQL, Maven, Java 21, Auth JWT (MVP) o IdP existente.
# SOLO en entorno sandbox, y tras revisión de S0.5:
# jhipster jdl ../../specs/domain.v2.draft.jdl --json-only
./mvnw test
```

## Angular

```bash
npx @angular/cli@latest new solarcare-web --directory=apps/solarcare-web --routing --style=css --standalone --strict --skip-git
cd apps/solarcare-web
npx ng add tailwindcss
npx ng g c features/installations/pages/installation-list --standalone
npx ng g s core/demo/demo-store
npx ng test --watch=false
```

## Flutter + FVM

```bash
mkdir -p apps/solarcare-mobile && cd apps/solarcare-mobile
fvm install 3.50.1
fvm use 3.50.1
fvm flutter create --project-name solarcare_mobile --org ar.solarcare --platforms=android,ios .
fvm flutter pub add flutter_riverpod go_router dio drift sqlite3_flutter_libs path_provider
fvm flutter pub add --dev build_runner drift_dev
fvm flutter analyze && fvm flutter test
```

## Firmware ESP32 (opcional)

```bash
idf.py create-project solarcare-sensor
cd solarcare-sensor
idf.py set-target esp32
idf.py build
# idf.py -p <PUERTO_VALIDADO> flash monitor
```

## Docker Compose DEV

```bash
cp infra/.env.example infra/.env
# Cambiar contraseña del archivo infra/.env
docker compose --env-file infra/.env -f infra/compose.infra.yaml config
docker compose --env-file infra/.env -f infra/compose.infra.yaml up -d
```

**Nota:** los comandos de generación son punto de partida. JHipster pregunta detalles de la aplicación y debe validarse contra el repositorio existente; no se han ejecutado en este paquete. Las plantillas de edge/cloud contienen nombres de imágenes a construir y no son un despliegue listo.
