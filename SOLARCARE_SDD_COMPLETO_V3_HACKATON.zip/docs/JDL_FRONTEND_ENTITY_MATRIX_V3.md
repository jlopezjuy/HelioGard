# SolarCare — matriz JDL → UX y navegación (v3)

**Fuente de verdad:** `specs/domain.v2.draft.jdl` (37 entidades, 83 relaciones). Es un borrador del dominio; no es un backend validado.
**Decisión de experiencia:** organizar la navegación por tareas de usuario, NO generar 37 CRUD como menú principal. Cada entidad aparece como pantalla, sección, diálogo, ficha o dato auxiliar.

| Dominio funcional | Ruta de entrada | Entidades | Experiencia protagonista |
|---|---|---|---|
| Organizaciones y permisos | `/organizaciones` | 3 | selector de empresa activa, miembros/roles y permisos de terceros; pruebas negativas entre tenants |
| Instalaciones y equipamiento | `/instalaciones` | 9 | ficha de sitio, plano esquemático, inventario por arreglos y strings, gateway y canales |
| Monitoreo y diagnóstico | `/monitoreo` | 6 | telemetría, línea temporal, modelo esperado/real, alertas y atribución cualificada |
| Economía energética | `/economia` | 3 | tarifas con vigencia, autoconsumo/exportación, pérdidas con ARS y supuestos |
| Auditorías | `/auditorias` | 6 | checklist paso a paso con evidencias, hallazgos, revisión y expediente |
| Cobertura y mantenimiento | `/mantenimiento` | 10 | planes versionados, propuestas, contratos, orden, técnico/dron, intervención y verificación |

## Inventario y tratamiento de TODAS las entidades

| Entidad JDL | Módulo | Tratamiento UI |
|---|---|---|
| `Organization` | Organizaciones y permisos | Pantalla/ficha protagonista |
| `OrganizationMembership` | Organizaciones y permisos | Pantalla/ficha protagonista |
| `InstallationAccessGrant` | Organizaciones y permisos | Pantalla/ficha protagonista |
| `Site` | Instalaciones y equipamiento | Pantalla/ficha protagonista |
| `Installation` | Instalaciones y equipamiento | Pantalla/ficha protagonista |
| `EquipmentModel` | Instalaciones y equipamiento | Soporte: embebido, editor contextual o tabla de administración |
| `SolarArray` | Instalaciones y equipamiento | Soporte: embebido, editor contextual o tabla de administración |
| `SolarString` | Instalaciones y equipamiento | Soporte: embebido, editor contextual o tabla de administración |
| `Equipment` | Instalaciones y equipamiento | Pantalla/ficha protagonista |
| `Gateway` | Instalaciones y equipamiento | Pantalla/ficha protagonista |
| `MetricDefinition` | Instalaciones y equipamiento | Soporte: embebido, editor contextual o tabla de administración |
| `TelemetryChannel` | Instalaciones y equipamiento | Soporte: embebido, editor contextual o tabla de administración |
| `AlertRule` | Monitoreo y diagnóstico | Soporte: embebido, editor contextual o tabla de administración |
| `Incident` | Monitoreo y diagnóstico | Pantalla/ficha protagonista |
| `IncidentEvent` | Monitoreo y diagnóstico | Soporte: embebido, editor contextual o tabla de administración |
| `EnergyModelRun` | Monitoreo y diagnóstico | Pantalla/ficha protagonista |
| `LossAssessment` | Monitoreo y diagnóstico | Pantalla/ficha protagonista |
| `LossCauseEstimate` | Monitoreo y diagnóstico | Soporte: embebido, editor contextual o tabla de administración |
| `TariffPlan` | Economía energética | Pantalla/ficha protagonista |
| `TariffRate` | Economía energética | Soporte: embebido, editor contextual o tabla de administración |
| `EconomicAssessment` | Economía energética | Pantalla/ficha protagonista |
| `AuditTemplate` | Auditorías | Soporte: embebido, editor contextual o tabla de administración |
| `AuditQuestion` | Auditorías | Soporte: embebido, editor contextual o tabla de administración |
| `AuditReport` | Auditorías | Pantalla/ficha protagonista |
| `AuditAnswer` | Auditorías | Soporte: embebido, editor contextual o tabla de administración |
| `AuditFinding` | Auditorías | Pantalla/ficha protagonista |
| `AuditEvidence` | Auditorías | Soporte: embebido, editor contextual o tabla de administración |
| `MaintenancePlan` | Cobertura y mantenimiento | Soporte: embebido, editor contextual o tabla de administración |
| `MaintenancePlanVersion` | Cobertura y mantenimiento | Soporte: embebido, editor contextual o tabla de administración |
| `ServiceAgreement` | Cobertura y mantenimiento | Soporte: embebido, editor contextual o tabla de administración |
| `PlanSubscription` | Cobertura y mantenimiento | Pantalla/ficha protagonista |
| `ServiceProposal` | Cobertura y mantenimiento | Pantalla/ficha protagonista |
| `WorkOrder` | Cobertura y mantenimiento | Pantalla/ficha protagonista |
| `WorkOrderTask` | Cobertura y mantenimiento | Soporte: embebido, editor contextual o tabla de administración |
| `MaintenanceIntervention` | Cobertura y mantenimiento | Soporte: embebido, editor contextual o tabla de administración |
| `InterventionEvidence` | Cobertura y mantenimiento | Soporte: embebido, editor contextual o tabla de administración |
| `RecoveryAssessment` | Cobertura y mantenimiento | Soporte: embebido, editor contextual o tabla de administración |

## Reglas de consistencia cruzada
- No mostrar datos de otra organización al cambiar tenant. El frontend solo simula esta protección; backend real deberá imponer permisos.
- `EquipmentModel` y `MetricDefinition` son catálogos globales de solo lectura para roles comunes.
- `InstallationAccessGrant`: el propietario conserva titularidad; un proveedor accede SOLO a instalaciones autorizadas.
- `EnergyModelRun` → `LossAssessment` → `LossCauseEstimate` → `EconomicAssessment`: conservar relación y distinguir estimaciones de mediciones.
- `AuditTemplate`/`AuditQuestion`: versión de auditoría inmutable tras publicación; los reportes deben mantener su plantilla original.
- `MaintenancePlanVersion`: propuestas y suscripciones no cambian sus condiciones si el plan comercial se actualiza.
- `WorkOrder`→`MaintenanceIntervention`→`RecoveryAssessment`: validar cierre después de la intervención, no por pulsar un botón de éxito.
- IDs de las relaciones deben ser coherentes dentro de fixtures y no apuntar entre tenants salvo autorización explícita.
- Serie temporal (`telemetry_measurement`) NO está en JDL: simular series temporales por intervalos como fixture independiente, usando W/kW versus Wh/kWh correctamente.

## Rutas transversales propuestas
`/inicio`, `/instalaciones`, `/instalaciones/:id`, `/monitoreo`, `/alertas`, `/economia`, `/auditorias`, `/auditorias/:id`, `/mantenimiento`, `/ordenes/:id`, `/planes`, `/organizaciones`, `/configuracion`, `/demo`.
La UI adapta acciones al rol propietario, técnico, empresa instaladora o admin de plataforma; evita menús vacíos y rutas muertas.

## Criterio de cobertura
Todo nombre de `entity ...` del JDL debe aparecer en esta matriz y en un tipo TypeScript, contrato o fixture. Las entidades auxiliares deben estar accesibles a través de un flujo real, no necesariamente como ruta independiente.
