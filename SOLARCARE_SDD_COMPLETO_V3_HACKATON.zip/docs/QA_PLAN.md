# QA: estrategia y datos de prueba

## Pirámide

- Backend: JUnit5/Spring Boot Test + Testcontainers PostgreSQL; autorización tenant por endpoints/repositorios; migraciones Liquibase en CI.
- Edge: pytest, tests de adaptadores con fixtures, cola duradera, pérdida de paquetes y corrupción parcial; validar schema de evento.
- Angular: unit y component tests; Playwright para flujos de administración y auditoría.
- Flutter: unit/widget/integration tests con repositorios fake, emulador Android e iOS en macOS; conexión LAN real cuando proceda.
- Contratos: validar JSON Schema, OpenAPI, timestamps y compatibilidad hacia atrás; fixture por cada inversor soportado.
- Energía: casos golden comparando salida de pvlib con parámetros/irradiancia conocidos; inspección humana de supuestos.

## Matriz de fallos

1. **Cero energía nocturna:** no dispara alerta de producción.
2. **Nubes:** no diagnosticar suciedad automáticamente.
3. **ESP32 reinicia:** duplicados/reintentos no generan doble conteo.
4. **Gateway sin WAN:** persiste mediciones y alertas locales; reconecta con backoff.
5. **Gateway sin reloj correcto:** marcar CLOCK_SKEW, bloquear cálculos sensibles a fecha.
6. **Cloud inactivo:** local sigue operando y almacena outbox.
7. **Medidor reinicia contador:** detectar reset, no energía negativa.
8. **Carga de batería restringida por BMS:** distinguir de panel defectuoso.
9. **Granizo:** alertar posible daño sin concluirlo automáticamente.
10. **Tarifas por vigencia:** usar precio correcto por intervalo.
11. **Cross tenant:** A no accede a objetos de B, aunque conozca ID.
12. **Offline técnico:** conflictos de hallazgo aparecen, ninguna foto se pierde silenciosamente.
13. **Mes con datos faltantes:** mostrar cobertura; no extrapolar como precisión alta.
14. **Restauración:** recuperar DB, evidencia y outbox con procedimiento probado.

## Revisión de modelo

No generar porcentajes de confianza ficticios. Las medidas son verificadas/estimadas, con método, cobertura temporal y evento de origen. La atribución a polvo requiere evidencia adicional o historial suficiente. Intervenciones deben compararse bajo irradiancia/temperatura equivalentes.

## Gates

- Sin pruebas de aislamiento tenant: NO deploy.
- Sin idempotencia de outbox: NO sync cloud.
- Sin calidad de dato: NO pérdida monetaria como dato comprobado.
- Sin profesional habilitado: NO emitir certificado de seguridad eléctrica.
- Sin evaluación del fabricante y control legal: NO comandar drones, robots, inversor ni baterías.
