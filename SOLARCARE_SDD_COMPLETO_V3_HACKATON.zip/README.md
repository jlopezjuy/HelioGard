# SolarCare v3 — paquete completo de hackatón

Extraer el ZIP en una carpeta vacía o mezclar conscientemente con el repositorio existente. La **raíz de extracción** debe contener `README.md`, `specs/`, `docs/`, `prompts/`, `frontend-demo/`, `skills/`, `infra/` y `demos/`. Para dar la instrucción a cualquier IA, usar `prompts/PROMPT_MAESTRO_ANGULAR_FRONTEND_MOCK_V3.md`.

# SolarCare — SDD Starter (documentación y contratos)

Paquete **documental y de fixtures/simuladores**, no aplicación Angular ejecutable terminada. Contiene arquitectura, sprints, especificaciones, ejemplos de contratos y una infraestructura Docker para desarrollo.

## Leer en este orden

1. [`docs/PLAN_MAESTRO_SDD.md`](docs/PLAN_MAESTRO_SDD.md) — arquitectura, decisiones, modelo, CLI y roadmap.
2. [`specs/CORE_REQUIREMENTS.md`](specs/CORE_REQUIREMENTS.md) — historias testables y no funcionales.
3. [`docs/ADR.md`](docs/ADR.md) — decisiones que no deberían cambiarse sin análisis.
4. [`docs/SPRINT_BOARD.md`](docs/SPRINT_BOARD.md) — vertical slices y criterios por sprint.
5. [`contracts/telemetry-event.schema.json`](contracts/telemetry-event.schema.json) — estructura base de la telemetría.
6. [`specs/domain.v2.draft.jdl`](specs/domain.v2.draft.jdl) — contrato JDL **v2**, 37 entidades, borrador sujeto a validación. `domain.initial.jdl` es histórico.
7. [`contracts/openapi.yaml`](contracts/openapi.yaml) — API mínima ilustrativa; ampliar antes de implementar.
8. [`prompts/CODEX_SDD.md`](prompts/CODEX_SDD.md) — prompt de coordinación técnica sin alucinaciones.

## Comprobar que tenemos herramientas

```bash
java -version
node --version
npx ng version
fvm --version
fvm flutter --version
docker compose version
```

## Docker: solo servicios de desarrollo

El archivo `infra/compose.infra.yaml` levanta Postgres, MQTT y Mailpit **sin ejecutar aún las apps**, que se deben generar con los CLI. Para ejecutar:

```bash
cp infra/.env.example infra/.env
# Editar la contraseña de PostgreSQL; .env está ignorado por Git.
docker compose --env-file infra/.env -f infra/compose.infra.yaml config
docker compose --env-file infra/.env -f infra/compose.infra.yaml up -d
```

El broker MQTT del entorno DEV se limita a 127.0.0.1 y acepta conexiones anónimas únicamente para pruebas locales. **Prohibido usar en producción o exponer a la red.** Edge/cloud tendrán autenticación, TLS y secretos gestionados.

## Alcance

Incluye especificaciones y base de planificación. **No** contiene el firmware, el backend JHipster, el frontend Angular ni la app Flutter generados; tampoco fue probado contra un inversor real.


## Revisión del modelo de datos — v2 (22 noviembre 2026)

El JDL de cuatro entidades `specs/domain.initial.jdl` es histórico/introductorio y **no suficiente**.

- `specs/domain.v2.draft.jdl`: propuesta ampliada de entidades y relaciones; requiere verificación con CLI exacto.
- `docs/MODELO_ER_MULTITENANT_V2.md`: ERD modular, 3FN, excepciones por tenant, límites de SDD y reparto por sprints.
- `database/tenant-integrity.example.sql`: ejemplo **no ejecutable directamente** de constraints multiempresa y RLS.
- `database/telemetry.example.sql`: ejemplo de tablas especializadas para eventos de telemetría, particiones y dedup.

**Gate S0.5:** jamás asumir que los CRUD generados por JHipster aplican aislamiento. Generar en una rama y probar con usuarios de dos empresas antes de avanzar.

## v3 — Frontend sin backend para la hackatón

- **Empezar aquí:** [`docs/FRONTEND_DEMO_QUICKSTART_V3.md`](docs/FRONTEND_DEMO_QUICKSTART_V3.md).
- **Prompt para implementar Angular:** [`prompts/PROMPT_MAESTRO_ANGULAR_FRONTEND_MOCK_V3.md`](prompts/PROMPT_MAESTRO_ANGULAR_FRONTEND_MOCK_V3.md).
- **Diseño sin AI slop:** [`docs/DESIGN_SYSTEM_QUEBRADA_V3.md`](docs/DESIGN_SYSTEM_QUEBRADA_V3.md).
- **Cobertura JDL 37/37:** [`docs/JDL_FRONTEND_ENTITY_MATRIX_V3.md`](docs/JDL_FRONTEND_ENTITY_MATRIX_V3.md).
- **Plan F0–F7:** [`docs/FRONTEND_FIRST_SPRINTS_V3.md`](docs/FRONTEND_FIRST_SPRINTS_V3.md).
- **Skill local:** [`skills/solarcare-visual-design/SKILL.md`](skills/solarcare-visual-design/SKILL.md).
- **Fixtures base:** `frontend-demo/`. No se ha generado todavía `apps/solarcare-web`.
- **Demos anteriores:** `demos/`, como referencia de interacción, NO sustituto de Angular.
