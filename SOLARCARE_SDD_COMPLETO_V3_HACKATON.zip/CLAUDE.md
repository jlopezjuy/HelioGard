# SolarCare — guía de implementación

La instrucción principal está en `prompts/PROMPT_MAESTRO_ANGULAR_FRONTEND_MOCK_V3.md`.
Leela junto a `specs/domain.v2.draft.jdl`, `docs/JDL_FRONTEND_ENTITY_MATRIX_V3.md`, `docs/FRONTEND_FIRST_SPRINTS_V3.md` y `skills/solarcare-visual-design/SKILL.md` antes de modificar archivos. Construir Angular + Tailwind con mocks, sin backend; no fingir pruebas ni acceso real a equipos.
