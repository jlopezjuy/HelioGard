# Sprint board orientado a entregas verticales

**Duración:** Sprint 0 de descubrimiento; S1–S10 de 1 a 2 semanas sujeto a capacidad. Una historia no está Done sin evidencia reproducible.

| Sprint | Demo / aceptación | Artefactos SDD obligatorios |
|---|---|---|
| S0 | dashboard actual evaluado; protocolo y muestra real/simulada rotulada | contexto, FR/NFR, ADR, API/telemetry contract, fixtures |
| S1 | login web, usuario/empresa e instalación por API + mobile shell | JDL de negocio, Liquibase, tests tenant |
| S2 | una medición de un inversor/simulador se ve en Angular y Flutter LAN | adapter contract, MQTT schema, quality flags |
| S3 | Raspberry desconectada de WAN continúa capturando y sincroniza al reconectar | outbox spec, pairing spec, idempotency tests |
| S4 | energía esperada vs real para un intervalo y condiciones explícitas | model spec, version y golden fixtures |
| S5 | evento de falla dispara incidente deduplicado, notificación y acuse | alert rules, climate profiles, state diagram |
| S6 | déficit total kWh y pesos con supuestos y causas desconocidas | tariff model, cost tests, non-double-count tests |
| S7 | técnico llena auditoría offline y firma/entrega hallazgos | audit checklist spec, evidence access, report |
| S8 | alerta→solicitud→técnico→intervención→verificación | OT/plan contracts y SLA terms |
| S9 | fallas de red, autenticación, backup y seguridad superadas | QA report, restore drill, perf tests |
| S10 | piloto documentado con errores reales y backlog | pilot report, support runbook, rollout checklist |

## Acuerdos de equipo

- Cada sprint debe agregar **un flujo end-to-end observable**; nada de 4 sprints seguidos solo creando entidades.
- PR: referencia a FR, cambios a contratos, migraciones, captura de prueba y plan de rollback.
- No cambiar el dashboard existente sin evaluar el costo de integración.
- Cambiar sensores o control OT requiere revisión de seguridad eléctrica.
- Mantener backlog separado para drones, robots, seguros, IA generativa y pagos; no son bloqueantes del MVP.
