# SolarCare — SDD Starter (documentación y contratos)

Paquete **documental**, no aplicación ejecutable terminada. Contiene arquitectura, sprints, especificaciones, ejemplos de contratos y una infraestructura Docker para desarrollo.

## Leer en este orden

1. [`docs/PLAN_MAESTRO_SDD.md`](docs/PLAN_MAESTRO_SDD.md) — arquitectura, decisiones, modelo, CLI y roadmap.
2. [`specs/CORE_REQUIREMENTS.md`](specs/CORE_REQUIREMENTS.md) — historias testables y no funcionales.
3. [`docs/ADR.md`](docs/ADR.md) — decisiones que no deberían cambiarse sin análisis.
4. [`docs/SPRINT_BOARD.md`](docs/SPRINT_BOARD.md) — vertical slices y criterios por sprint.
5. [`contracts/telemetry-event.schema.json`](contracts/telemetry-event.schema.json) — estructura base de la telemetría.
6. [`specs/domain.initial.jdl`](specs/domain.initial.jdl) — entidades iniciales JHipster, sujetas a revisión.
7. [`contracts/openapi.yaml`](contracts/openapi.yaml) — API mínima ilustrativa; ampliar antes de implementar.
8. [`prompts/CODEX_SDD.md`](prompts/CODEX_SDD.md) — prompt de coordinación técnica sin alucinaciones.

## Comprobar que tenemos herramientas

```bash
java -version
node --version
npx ng version
fvm --version
fvm flutter --version
docker compose version
```

## Docker: solo servicios de desarrollo

El archivo `infra/compose.infra.yaml` levanta Postgres, MQTT y Mailpit **sin ejecutar aún las apps**, que se deben generar con los CLI. Para ejecutar:

```bash
cp infra/.env.example infra/.env
# Editar la contraseña de PostgreSQL; .env está ignorado por Git.
docker compose --env-file infra/.env -f infra/compose.infra.yaml config
docker compose --env-file infra/.env -f infra/compose.infra.yaml up -d
```

El broker MQTT del entorno DEV se limita a 127.0.0.1 y acepta conexiones anónimas únicamente para pruebas locales. **Prohibido usar en producción o exponer a la red.** Edge/cloud tendrán autenticación, TLS y secretos gestionados.

## Alcance

Incluye especificaciones y base de planificación. **No** contiene el firmware, el backend JHipster, el frontend Angular ni la app Flutter generados; tampoco fue probado contra un inversor real.
